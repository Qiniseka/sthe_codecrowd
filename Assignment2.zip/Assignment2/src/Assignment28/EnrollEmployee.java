package Assignment28;

import static Assignment28.IEmployee.DEVELOPER;
import static Assignment28.IEmployee.EXEC;
import static Assignment28.IEmployee.MANANGER;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A204519
 */
public class EnrollEmployee {
    public static void main(String[] args) {
        BankEmployee bob = new BankEmployee("Bob", MANANGER, 30, 30000);
        BankEmployee jerry = new BankEmployee("Jerry", DEVELOPER, 20, 20000);
        BankEmployee tom = new BankEmployee("Tom", EXEC, 40, 50000);
        
        bob.activateEmployee();
        jerry.activateEmployee();
        tom.activateEmployee();
        
        bob.displayEmployee();
        jerry.displayEmployee();
        tom.displayEmployee();
        
        bob.deactivateEmployee();
        
        BankEmployee newOne = bob;
        
    }
    
}
